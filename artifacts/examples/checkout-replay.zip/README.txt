NetScope model-preserved regression bundle

Install the NetScope release, then run:
  netscope replay project.yaml preservation.json

Optional real-cluster verification:
  netscope verify project.yaml --context kind-netscope-lab --allow-live

No runtime evidence is embedded or implied. Fixed topology; selected-witness preservation only.
